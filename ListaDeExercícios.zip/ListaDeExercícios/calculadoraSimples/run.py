def soma(a, b):
    return a + b

soma(2, 3)


def subtracao(a, b):
    return a - b 

subtracao(10, 3)

def multipicacao(a, b):
    return a * b

def divisao(a, b):
    return a/b