def dolar_to_euro(valor, cot):
    return round((valor / cot), 2)

dolar_to_euro(10, 0.95)


def euro_to_dolar(valor, cot):
    return round((valor * cot), 2)

euro_to_dolar(10, 0.95)


def real_to_dolar(valor, cot):
    return round((valor / cot), 2)

real_to_dolar(10, 5.77)


def dolar_to_real(valor, cot):
    return round((valor * cot), 2)

dolar_to_real(10, 5.77)